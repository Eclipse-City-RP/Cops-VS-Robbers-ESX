-- client.lua

local isCopsTeam = false
local isRobbersTeam = false

RegisterNetEvent('startCopsVsRobbers')
AddEventHandler('startCopsVsRobbers', function()
    local playerPed = GetPlayerPed(-1)
    
    -- Clear existing team assignments
    isCopsTeam = false
    isRobbersTeam = false

    -- Example: Teleport all players to the same starting point
    SetEntityCoords(playerPed, 0.0, 0.0, 0.0, true, false, false, true)

    -- Random team assignment
    if math.random() > 0.5 then
        -- Teleport players into a random cop vehicle
        local copVehicles = {"police", "police2", "police3", "police4", "policeb", "policet", "polmav"}
        local randomCopCar = GetHashKey(copVehicles[math.random(1, #copVehicles)])
        local copVehicle = CreateVehicle(randomCopCar, 5.0, 0.0, 0.0, 0.0, true, false)
        TaskWarpPedIntoVehicle(playerPed, copVehicle, -1)
        isCopsTeam = true
    else
        -- Teleport players into a random robber vehicle
        local robberVehicles = {"adder", "comet2", "feltzer2", "jester", "elegy2"}
        local randomRobberCar = GetHashKey(robberVehicles[math.random(1, #robberVehicles)])
        local robberVehicle = CreateVehicle(randomRobberCar, -5.0, 0.0, 0.0, 0.0, true, false)
        TaskWarpPedIntoVehicle(playerPed, robberVehicle, -1)
        isRobbersTeam = true
    end

    TriggerEvent('chatMessage', 'SYSTEM', {255, 0, 0}, 'Cops vs Robbers game mode started!')

    -- Example: Set game objective based on teams
    if isCopsTeam then
        TriggerEvent('chatMessage', 'OBJECTIVE', {0, 128, 255}, 'Objective: Apprehend the robbers!')
    elseif isRobbersTeam then
        TriggerEvent('chatMessage', 'OBJECTIVE', {255, 69, 0}, 'Objective: Evade the cops and switch vehicles!')
    end

    -- Example: Wait for 10 seconds before allowing cops to pursue
    if isCopsTeam then
        Wait(10000) -- 10 seconds in milliseconds
        TriggerEvent('chatMessage', 'SYSTEM', {255, 0, 0}, 'Cops can now pursue the robbers!')
    end

    -- Example: Wait for 30 seconds before indicating switch vehicles
    if isRobbersTeam then
        Wait(30000) -- 30 seconds in milliseconds
        TriggerEvent('chatMessage', 'OBJECTIVE', {255, 69, 0}, 'Objective: Switch vehicles now!')
    end

    -- Example: Wait for 60 seconds before indicating escape route
    if isRobbersTeam then
        Wait(60000) -- 60 seconds in milliseconds
        TriggerEvent('chatMessage', 'OBJECTIVE', {255, 69, 0}, 'Objective: Head to the escape point!')
    end
end)

RegisterNetEvent('playerDied')
AddEventHandler('playerDied', function()
    TriggerServerEvent('playerDied') -- Inform the server that the player died
end)