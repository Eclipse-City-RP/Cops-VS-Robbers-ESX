-- config.lua

Config = {}

-- Reward amounts
Config.RobbersRewardAmount = 500
Config.CopsRewardAmount = 1000

-- Game cost
Config.GameCost = 14.99