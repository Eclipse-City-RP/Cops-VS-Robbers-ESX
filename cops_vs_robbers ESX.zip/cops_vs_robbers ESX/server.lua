-- server.lua

local playersAlive = {}

RegisterCommand('startcopsrobbers', function(source, args, rawCommand)
    local xPlayer = ESX.GetPlayerFromId(source)

    -- Check if the player has permission to start the game mode (adjust permissions as needed)
    if xPlayer.getGroup() == 'admin' then
        TriggerClientEvent('startCopsVsRobbers', -1) -- Broadcast to all clients
        TriggerEvent('chatMessage', 'SYSTEM', {255, 0, 0}, 'Cops vs Robbers game mode started!')
    else
        TriggerClientEvent('chatMessage', source, 'SYSTEM', {255, 0, 0}, 'You do not have permission to start the game mode!')
    end
end, false)

RegisterNetEvent('playerDied')
AddEventHandler('playerDied', function()
    local source = source
    playersAlive[source] = false

    local allPlayersDead = true
    for _, alive in pairs(playersAlive) do
        if alive then
            allPlayersDead = false
            break
        end
    end

    if allPlayersDead then
        -- Determine winning and losing teams based on objectives achieved
        local winningTeam = GetWinningTeam()
        if winningTeam then
            -- Reward players
            RewardPlayers(winningTeam)
        end

        TriggerClientEvent('chatMessage', -1, 'SYSTEM', {255, 0, 0}, 'All players are dead. Game over!')
        -- Implement any other game-over actions, such as displaying winners or ending the game.
    end
end)

function GetWinningTeam()
    -- Implement your logic to determine the winning team based on objectives achieved
    -- For simplicity, let's assume the cops win if there's at least one robber alive, and vice versa.
    local copsAlive = false
    local robbersAlive = false

    for _, alive in pairs(playersAlive) do
        if alive then
            if IsPlayerInCopsTeam(_) then
                copsAlive = true
            elseif IsPlayerInRobbersTeam(_) then
                robbersAlive = true
            end
        end
    end

    if copsAlive and not robbersAlive then
        return 'cops'
    elseif robbersAlive and not copsAlive then
        return 'robbers'
    end

    return nil
end

function RewardPlayers(winningTeam)
    local xPlayers = ESX.GetPlayers()

    for _, source in pairs(xPlayers) do
        local xPlayer = ESX.GetPlayerFromId(source)

        if winningTeam == 'cops' and IsPlayerInCopsTeam(source) then
            xPlayer.addMoney(1000)
        elseif winningTeam == 'robbers' and IsPlayerInRobbersTeam(source) then
            xPlayer.addMoney(1000)
        else
            xPlayer.addMoney(100)
        end
    end
end

function IsPlayerInCopsTeam(source)
    -- Implement your logic to check if a player is in the cops team
    -- For simplicity, let's assume players are assigned to teams during the round start.
    return true -- Replace with your actual logic
end

function IsPlayerInRobbersTeam(source)
    -- Implement your logic to check if a player is in the robbers team
    -- For simplicity, let's assume players are assigned to teams during the round start.
    return true -- Replace with your actual logic
end